
 1. About

 HXNTVDM is a DPMI TSR, which extends DPMI capabilities inside a WinXP
 NTVDM. DPMI interrupt Int 31h is hooked and several functions are 
 handled by HXNTVDM and its helper Win32 dll HXVDD.DLL.

 1. int 31h, ax=401: reports host vendor "HXNTVDM"
 2. int 31h, ax=504: allocate linear memory
 3. int 31h, ax=506: get page attributes
 4. int 31h, ax=507: set page attributes

 Int 31h, ax=501/502/503 will be handled by HXVDD.DLL as well.


 2. Usage/Installation

 Usually it is a good idea to restrict the free memory reported by
 DPMI to avoid old applications trying to alloc all memory. For this
 to achieve the -m option can be used:

 HXNTVDM -m 64

 will report 64 MB free memory for the application.

 HXNTVDM can be added to AUTOEXEC.NT. 

 Due to a NTVDM restriction (which doesn't allow a 16bit client to run
 while a 32bit client is active) one cannot launch a 16bit client while
 HXNTVDM is installed.


 3. Create the Binaries

 Two makefiles, HXNTVDM.MAK and HXVDD.MAK are supplied (NMAKE format).
 Tools used a JWasm or Masm, WLink or MS Link, HXDEV and Win32Inc.


 4. License

 HXNTVDM and HXVDD are Freeware. Copyright Japheth 2007-2008.

